# SanjuSystemX V3

Kotlin Android project, package `com.sanju.systemx`. Open in Android Studio or build in GitHub Actions.

## Build
- Android Studio with JDK 17, Android SDK 35, Android Gradle Plugin 8.7.3.
- CI workflow: `.github/workflows/build.yml`; debug APK is uploaded as `SanjuSystemX-V3-debug-apk`.

## Setup and limits
1. Install and start the official Shizuku app/service, then grant SanjuSystemX permission inside the app.
2. Grant Usage Access in Android Settings for MLBB foreground detection.
3. Refresh-rate request applies to this app's window using Android display modes; OEM/game policies may override it. Actual active display refresh rate is read from Android.
4. Actual in-game FPS, GPU utilization/frequency, and touch sampling rate are not universally available to ordinary apps. This app does not fabricate them or write to undocumented sysfs controls.
5. The included cinematic mark is a simple red placeholder. Put your own permitted image at `app/src/main/res/drawable-nodpi/sanju_eye.png` and update `MainActivity.kt` if you want the supplied eye artwork rendered. The uploaded image is not automatically embedded into this source project.

## Current implementation scope
The dashboard, Shizuku connection/permission status, read-only shell capability probe, usage-access MLBB detection, actual display refresh-rate readout, app-window refresh-mode request, CPU usage estimate, intro animation, and CI build are implemented. Automatic restoration of device-wide changes is not needed because the app currently avoids making device-wide changes. FPS and GPU/touch controls remain explicitly unsupported unless a safe supported interface is available.
